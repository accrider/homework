import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class RejectionSampling {

	public static void main(String[] args) {
		try {
			Scanner scan = new Scanner(new File("survey.txt"));
			//Define probability distributions
			int g = 0;
			int h = 0;
			int t = 0;
			int m = 0;
			int total = 0;
			int[][] probP = new int[2][2];
			int[][][] probC = new int[2][2][2];
			

			//Scan through survey file and build the probabilities.
			while (scan.hasNext()) {
				String line = scan.nextLine();
				String[] parse = line.split(" ");
				short[] p = new short[parse.length];
				for (int i = 0; i < p.length; i++) {
					p[i] = Short.valueOf(parse[i]);
				}
				total++;
				g += p[0];
				h += p[1];
				t += p[2];
				m += p[3];
				probP[p[1]][p[2]] += p[4];
				probC[p[0]][p[3]][p[4]] += p[5];
			}

			System.out.println("Finding p(C|H=h)");

			int lN[] = new int[2];
			int nCon = 0;
			int N = 0;
			
			//Keep track of previous answer to check successive calculations
			double prevAns = 0.0;
			//Keep track of previous results to view changes in samples
			ArrayList<Double> results = new ArrayList<Double>();
			do {
				// sample bayes
				N++;
				short[] BN = new short[6];
				BN[0] = (short) (Math.random() < ((double) g / total) ? 1 : 0); //G
				BN[1] = (short) (Math.random() < ((double) h / total) ? 1 : 0); //H
				BN[2] = (short) (Math.random() < ((double) t / total) ? 1 : 0); //T
				BN[3] = (short) (Math.random() < ((double) m / total) ? 1 : 0); //M
				BN[4] = (short) (Math.random() < ((double) probP[BN[1]][BN[2]] / total) ? 1 : 0); //p(p|h,t)
				BN[5] = (short) (Math.random() < ((double) probC[BN[0]][BN[3]][BN[4]] / total) ? 1 : 0); //p(c|g,c,m)
				
				// when H = 1 inc lN[c]
				if (BN[1] == 1) {
					lN[BN[5]]++;
					nCon++;
					double curAns = lN[1] / (double) nCon;
					results.add(curAns);
					if (lN[1] > 0 && Math.abs(curAns - prevAns) < 0.001) break;
					
					prevAns = lN[1] / (double) nCon;
				}
			} while (true);
			
			double partition = (double) results.size() / 20;
			for (int i = 0; i < 20; i++) {
				System.out.println((i + 1) + ": " + results.get((int) (i*partition)));
			}
			System.out.println("Found after: " + N + " samples");
			System.out.println((double) lN[1] / nCon);
			
			System.out.println();
			
			System.out.println("Finding p(C|H=h)");
			
			results.clear();
			lN = new int[2];
			nCon = 0;
			N = 0;
			prevAns = 0.0;
			do {
				// sample bayes
				N++;
				short[] BN = new short[6];
				BN[0] = (short) (Math.random() < ((double) g / total) ? 1 : 0); //G
				BN[1] = (short) (Math.random() < ((double) h / total) ? 1 : 0); //H
				BN[2] = (short) (Math.random() < ((double) t / total) ? 1 : 0); //T
				BN[3] = (short) (Math.random() < ((double) m / total) ? 1 : 0); //M
				BN[4] = (short) (Math.random() < ((double) probP[BN[1]][BN[2]] / total) ? 1 : 0); //p(p|h,t)
				BN[5] = (short) (Math.random() < ((double) probC[BN[0]][BN[3]][BN[4]] / total) ? 1 : 0); //p(c|g,c,m)
				
				// when M = 1 inc lN[c]
				if (BN[3] == 1) {
					lN[BN[5]]++;
					nCon++;
					double curAns = lN[1] / (double) nCon;
					results.add(curAns);

					if (lN[1] > 0 && Math.abs(curAns - prevAns) < 0.0001) break;
					
					prevAns = lN[1] / (double) nCon;	
				}
			} while (true);
			
			partition = (double) results.size() / 20;
			for (int i = 0; i < 20; i++) {
				System.out.println((i + 1) + ": " + results.get((int) (i*partition)));
			}
			
			System.out.println("Found after: " + N + " samples");
			System.out.println((double) lN[1] / nCon);

			scan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}
