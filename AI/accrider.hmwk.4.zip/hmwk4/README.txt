Requirements:
Python 2.7
Matplotlib
Numpy

To run:
python main.py